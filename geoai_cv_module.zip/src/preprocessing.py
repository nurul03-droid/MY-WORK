"""
Stage 1 — Preprocessing
========================
Cleans up a scanned blueprint before line detection: deskew, denoise, binarize.

Tune here if:
  - Real scans are noisier/lower quality than test samples (increase denoise `h`)
  - Scans arrive rotated (deskew logic below handles moderate skew automatically)
"""

import cv2
import numpy as np


def load_grayscale(path: str) -> np.ndarray:
    """Load an image file as grayscale. Raises if the file can't be read."""
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    return img


def deskew(gray_img: np.ndarray) -> np.ndarray:
    """Detect and correct rotation using the minimum-area bounding rectangle
    of foreground pixels. Works well for moderately skewed scans; won't fix
    severe (>45 deg) rotation — flag those for manual rotation before upload."""
    _, thresh = cv2.threshold(gray_img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    coords = np.column_stack(np.where(thresh > 0))
    if len(coords) == 0:
        return gray_img

    angle = cv2.minAreaRect(coords)[-1]
    angle = -(90 + angle) if angle < -45 else -angle

    (h, w) = gray_img.shape
    matrix = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
    return cv2.warpAffine(
        gray_img, matrix, (w, h),
        flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE
    )


def denoise(gray_img: np.ndarray, strength: int = 10) -> np.ndarray:
    """Remove scan noise/dust. Increase `strength` for very noisy scans,
    but too high will blur thin boundary lines — 8-15 is a reasonable range."""
    return cv2.fastNlMeansDenoising(gray_img, h=strength)


def binarize(gray_img: np.ndarray) -> np.ndarray:
    """Otsu thresholding — works well for high-contrast line drawings
    like cadastral blueprints. Output: 255 = foreground (lines/text), 0 = background."""
    _, binary = cv2.threshold(gray_img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    return binary


def preprocess(path: str) -> np.ndarray:
    """Full preprocessing pipeline: load -> deskew -> denoise -> binarize."""
    gray = load_grayscale(path)
    straightened = deskew(gray)
    cleaned = denoise(straightened)
    return binarize(cleaned)
