"""
Stage 2 — Line detection (Hough Transform)
=============================================
Blueprint plot boundaries are straight lines, so Hough Line Transform finds
them far more reliably than generic edge/contour detection on its own.

Tune here if:
  - Lines are missing/broken -> increase max_line_gap
  - Too many false-positive lines -> increase threshold or min_line_length
  - Real-world plots have curved boundaries -> this approach assumes straight
    edges; you'd need a different technique (e.g. active contours) for curves
"""

import cv2
import numpy as np


def detect_line_mask(
    binary_img: np.ndarray,
    canny_low: int = 50,
    canny_high: int = 150,
    hough_threshold: int = 50,
    min_line_length: int = 30,
    max_line_gap: int = 10,
) -> np.ndarray:
    """Returns a binary mask (255 = detected line pixel) from Hough-detected
    straight line segments."""
    edges = cv2.Canny(binary_img, canny_low, canny_high)
    lines = cv2.HoughLinesP(
        edges, rho=1, theta=np.pi / 180, threshold=hough_threshold,
        minLineLength=min_line_length, maxLineGap=max_line_gap
    )

    line_mask = np.zeros_like(binary_img)
    if lines is not None:
        for x1, y1, x2, y2 in lines[:, 0]:
            cv2.line(line_mask, (x1, y1), (x2, y2), 255, thickness=2)
    return line_mask


def close_gaps(line_mask: np.ndarray, kernel_size: int = 5, iterations: int = 2) -> np.ndarray:
    """Morphological closing to bridge small breaks in detected lines
    (common with hand-drawn or lower-quality scans) so contours later
    form closed shapes instead of open ones."""
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    return cv2.morphologyEx(line_mask, cv2.MORPH_CLOSE, kernel, iterations=iterations)
