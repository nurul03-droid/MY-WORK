"""
Stage 3 — Vectorization
=========================
Converts the closed-line raster mask into clean polygon shapes: extracts
contours, filters noise, and simplifies jagged pixel edges into straight
polygon edges (blueprints have straight edges, so this matters a lot).

Tune here if:
  - Small noise blobs are detected as plots -> increase min_area
  - Polygons look too jagged/pixel-stepped -> increase epsilon_ratio
  - Real plot corners get rounded off -> decrease epsilon_ratio
"""

import cv2
import numpy as np
from shapely.geometry import Polygon


def extract_contours(closed_mask: np.ndarray, min_area: int = 300) -> list:
    """Find closed shapes in the mask, filtering out contours smaller than
    min_area (tune based on your image resolution — noise vs real plots)."""
    contours, _ = cv2.findContours(closed_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    return [c for c in contours if cv2.contourArea(c) > min_area]


def contours_to_polygons(contours: list, epsilon_ratio: float = 0.01) -> list:
    """Simplify each contour into a clean straight-edge polygon using
    Douglas-Peucker approximation, then convert to a Shapely Polygon."""
    polygons = []
    for c in contours:
        epsilon = epsilon_ratio * cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, epsilon, True)
        if len(approx) < 3:
            continue
        pts = [tuple(p[0]) for p in approx]
        poly = Polygon(pts)
        if poly.is_valid and poly.area > 0:
            polygons.append(poly)
    return polygons
