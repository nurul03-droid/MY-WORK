"""
Pipeline — single entry point for the rest of the team
=========================================================
This is the only function other team members (backend, OCR) need to import.
Everything else in this package is internal detail you can freely retune.
"""

from .preprocessing import preprocess
from .line_detection import detect_line_mask, close_gaps
from .vectorization import extract_contours, contours_to_polygons


def detect_plots(
    image_path: str,
    min_area: int = 300,
    epsilon_ratio: float = 0.01,
) -> list[dict]:
    """
    Run the full preprocessing -> line detection -> vectorization pipeline.

    Returns a list of dicts, one per detected plot:
        {
            "polygon_points": [[x1, y1], [x2, y2], ...],  # closed ring, pixel coords
            "area_px": 15234.5,                             # area in pixel^2, NOT real-world area
        }

    Downstream (backend) converts polygon_points to real coordinates and
    recomputes area after that conversion — don't do unit conversion here.
    """
    binary = preprocess(image_path)
    line_mask = detect_line_mask(binary)
    closed = close_gaps(line_mask)
    contours = extract_contours(closed, min_area=min_area)
    polygons = contours_to_polygons(contours, epsilon_ratio=epsilon_ratio)

    return [
        {
            "polygon_points": list(poly.exterior.coords),
            "area_px": poly.area,
        }
        for poly in polygons
    ]
