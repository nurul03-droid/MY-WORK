"""
Sanity tests using a synthetic drawn image (a plain rectangle) so the
pipeline can be verified without needing a real blueprint scan on hand.

Run with:
    pytest tests/
"""

import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.pipeline import detect_plots  # noqa: E402


def make_synthetic_blueprint(path: str):
    """Draws a simple rectangle to simulate a plot boundary."""
    img = np.full((400, 400), 255, dtype=np.uint8)
    cv2.rectangle(img, (50, 50), (300, 300), 0, thickness=3)
    cv2.imwrite(path, img)


def test_detects_one_rectangle(tmp_path):
    img_path = str(tmp_path / "synthetic.png")
    make_synthetic_blueprint(img_path)

    results = detect_plots(img_path, min_area=1000)

    assert len(results) >= 1, "Expected at least one detected plot"
    assert results[0]["area_px"] > 0
    assert len(results[0]["polygon_points"]) >= 3


def test_handles_blank_image(tmp_path):
    img_path = str(tmp_path / "blank.png")
    blank = np.full((200, 200), 255, dtype=np.uint8)
    cv2.imwrite(img_path, blank)

    results = detect_plots(img_path)
    assert results == [], "Blank image should produce no detected plots"
